package Util;
public class Restaurant {
	public Restaurant(){
		
	}
	//restaurant
	private String id;
	private String name;
	
	//restaurant_details
	private String phone;
	private String price; 
	private String url;
	private String image_url;
	private Location location;

	
	//category
	private Category [] categories;
	
	//rating_details
	private int review_count;
	private double rating;
	
	//get
	public String getPrice() {
		return this.price;
	}
	
	public String getUrl() {
		return this.url;
	}
	
	public Category[] getCategories() {
		return this.categories;
	}
	
	public int getReviewCount() {
		return this.review_count;
	}
	
	public double getRating() {
		return this.rating;
	}
	public String getId() {
		return this.id;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getImageUrl() {
		return this.image_url;
	}
	
	public Location getLocation() {
		return this.location;
	}
	
	public String getPhone() {
		return this.phone;
	}
	
	public String getStringCategories() {
		String ans = "";
		for(Category c : this.categories) {
			if (c != null) {
				ans += c.getTitle() + " ";
			}
			
		}
		return ans;
	}
	
	//set
	
	public void setPrice(String price) {
		this.price = price;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	public void setCategories(Category[] categories) {
		this.categories = categories;
	}

	public void setReviewCount(int review_count) {
		this.review_count = review_count;
	}
	
	public void setRating(double rating) {
		this.rating = rating;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setImageUrl(String image_url) {
		this.image_url = image_url;
	}
	
	public void setLocation(Location location) {
		this.location = location;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public void setLocationString(String str) {
		this.location = new Location();
		String[] ans = {str};
		this.location.setDisplayAddress(ans);
	}

}
