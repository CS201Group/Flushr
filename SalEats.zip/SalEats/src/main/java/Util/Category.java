package Util;
public class Category {
	public Category() {}
	private String title = "";
	
	//get
	public String getTitle() {
		return this.title;
	}
	
	
	//set
	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
