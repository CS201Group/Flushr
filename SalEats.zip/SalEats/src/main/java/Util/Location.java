package Util;
public class Location {

	private String[] display_address;
	
	public Location() {}
	//get
	public String[] getDisplayAddress() {
		return this.display_address;
	}
	public String getStringAddress() {
		return String.join(" ", this.display_address);
	}
	
	//set
	public void setDisplayAddress(String[] display_address) {
		this.display_address = display_address;
	}
}
