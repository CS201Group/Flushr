DROP DATABASE if exists SalEatsDB;

CREATE DATABASE SalEatsDB;

USE SalEatsDB;

CREATE TABLE Users (
  email varchar(100) primary key not null,
  name varchar(100) not null,
  password varchar(100) not null
);


CREATE TABLE Rating_details(
	rating_id varchar(200) primary key not null,
	review_count INT,
	rating DECIMAL
);

CREATE TABLE Restaurant_details(
	details_id varchar(200) primary key not null,
	image_url varchar(500),
	address varchar(300),
	phone_no varchar(20),
	estimated_price varchar(50),
	yelp_url varchar(500)
);

CREATE TABLE Restaurant(
	restaurant_id varchar(200) primary key not null,
	restaurant_name varchar(200) not null,
	details_id varchar(200) not null, 
	rating_id varchar(200) not null,
	FOREIGN KEY (details_id) REFERENCES Restaurant_details(details_id),
	FOREIGN KEY (rating_id) REFERENCES Rating_details(rating_id)
);

CREATE TABLE Category(
	category_id varchar(200) primary key not null,
	category_name varchar(200),
	restaurant_id varchar(200) not null,
	FOREIGN KEY (restaurant_id) REFERENCES Restaurant(restaurant_id)
);

CREATE TABLE Bridge_Table(
	category_id varchar(200),
    restaurant_id varchar(200)
);